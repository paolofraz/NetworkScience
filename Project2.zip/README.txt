Main.py is the main script used for computing the figures over the preprocessed data (which is in the folder 'Data') and to run the SI simulations.
Preprocessing.py is the python script for preprocessing the raw data to make use of the temporal features of the network, for potential use in the second part of the project
The data is present in the zip file so simply running the main.py file should produce the results as shown in the report
Burstiness.py was used to compute the rolling averages and Fano factor, toegheter with the annexed plots.